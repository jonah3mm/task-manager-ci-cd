import React, { useEffect, useState } from "react";
import "./index.css";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL || "http://localhost:5001";

function App() {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState("");
  const [darkMode, setDarkMode] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  // Fetch tasks on load
  useEffect(() => {
    console.log("Fetching tasks from backend at", BACKEND_URL);
    fetch(`${BACKEND_URL}/tasks`)
      .then((res) => {
        console.log("Backend responded with:", res);
        if (!res.ok) throw new Error("Network response not OK");
        return res.json();
      })
      .then((data) => {
        setTasks(data);
        setLoading(false);
        setError(false);
      })
      .catch((err) => {
        console.error("❌ Failed to fetch tasks from backend:", err);
        setError(true);
        setLoading(false);
      });
  }, []);

  const handleAddTask = () => {
    if (newTask.trim() === "") return;

    fetch(`${BACKEND_URL}/tasks`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: newTask }),
    })
      .then((res) => res.json())
      .then((createdTask) => {
        setTasks([...tasks, createdTask]);
        setNewTask("");
      })
      .catch((err) => console.error("❌ Error adding task:", err));
  };

  const handleDeleteTask = (id) => {
    fetch(`${BACKEND_URL}/tasks/${id}`, {
      method: "DELETE",
    })
      .then(() => {
        setTasks(tasks.filter((task) => task.id !== id));
      })
      .catch((err) => console.error("❌ Error deleting task:", err));
  };

  const handleToggleComplete = (id, completed) => {
    fetch(`${BACKEND_URL}/tasks/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ completed: !completed }),
    })
      .then((res) => res.json())
      .then((updatedTask) => {
        setTasks(
          tasks.map((task) =>
            task.id === id
              ? { ...task, completed: updatedTask.completed }
              : task
          )
        );
      })
      .catch((err) => console.error("❌ Error updating task:", err));
  };

  const handleClearCompleted = () => {
    const completedTasks = tasks.filter((task) => task.completed);
    completedTasks.forEach((task) => {
      fetch(`${BACKEND_URL}/tasks/${task.id}`, {
        method: "DELETE",
      });
    });
    setTasks(tasks.filter((task) => !task.completed));
  };

  const handleToggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  if (loading) {
    return <div className="container">Loading tasks...</div>;
  }

  if (error) {
    return (
      <div className="container">
        <h2 style={{ color: "red" }}>
          ❌ Cannot connect to backend at {BACKEND_URL}
        </h2>
        <p>Make sure the backend container is running.</p>
      </div>
    );
  }

  return (
    <div className={`container ${darkMode ? "dark-mode" : ""}`}>
      <button className="toggle-dark-mode-btn" onClick={handleToggleDarkMode}>
        Toggle Dark Mode
      </button>
      <h1>Task Manager</h1>

      <div className="input-container">
        <input
          type="text"
          placeholder="Add a new task"
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
        />
        <button className="add-task-btn" onClick={handleAddTask}>
          Add Task
        </button>
      </div>

      <button className="clear-completed-btn" onClick={handleClearCompleted}>
        Clear Completed Tasks
      </button>

      <ul>
        {tasks.map((task) => (
          <li key={task.id}>
            <input
              type="checkbox"
              checked={task.completed}
              onChange={() => handleToggleComplete(task.id, task.completed)}
            />
            <span className={task.completed ? "completed" : ""}>
              {task.text}
            </span>
            <button
              className="delete-btn"
              onClick={() => handleDeleteTask(task.id)}
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;

